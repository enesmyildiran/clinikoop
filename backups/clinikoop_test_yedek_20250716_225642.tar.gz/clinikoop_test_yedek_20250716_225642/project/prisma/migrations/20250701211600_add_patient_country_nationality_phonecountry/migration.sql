-- AlterTable
ALTER TABLE "patients" ADD COLUMN "country" TEXT;
ALTER TABLE "patients" ADD COLUMN "nationality" TEXT;
ALTER TABLE "patients" ADD COLUMN "phoneCountry" TEXT;
