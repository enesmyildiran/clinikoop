export const CURRENCIES = [
  { code: "EUR", label: "EUR (€)" },
  { code: "USD", label: "USD ($)" },
  { code: "TRY", label: "TRY (₺)" },
]; 