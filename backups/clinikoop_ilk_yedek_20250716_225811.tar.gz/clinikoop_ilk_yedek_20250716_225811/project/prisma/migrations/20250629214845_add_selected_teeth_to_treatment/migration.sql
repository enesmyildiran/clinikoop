-- AlterTable
ALTER TABLE "treatments" ADD COLUMN "selectedTeeth" TEXT;
