-- AlterTable
ALTER TABLE "patients" ADD COLUMN "allergies" TEXT;
ALTER TABLE "patients" ADD COLUMN "medicalHistory" TEXT;
