import { notFound } from 'next/navigation'

export default function SecuritySettingsPage() {
  // Bu sayfa henüz mevcut değil, 404 sayfasına yönlendir
  notFound()
} 