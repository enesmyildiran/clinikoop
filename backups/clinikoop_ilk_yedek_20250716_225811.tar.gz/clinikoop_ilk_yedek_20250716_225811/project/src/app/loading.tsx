import Loading from '@/components/ui/Loading'

export default function GlobalLoading() {
  return <Loading />
} 